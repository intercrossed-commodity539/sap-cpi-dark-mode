# SAP CPI Dark Mode

A comfortable charcoal dark theme for SAP Integration Suite and SAP Cloud Integration. It is designed for developers who spend long hours in the tool, with adjustable brightness, contrast, and warmth to reduce eye strain. The theme is scoped to SAP CPI pages only and does not affect other sites.

## Highlights

- Comfortable charcoal appearance that avoids a harsh pure black.
- One click comfort presets: Soft, Comfort, and Deep.
- Fine tune controls for Brightness, Contrast, Warmth, and Saturation.
- Warmth control lowers blue light for easier reading during long sessions.
- Keyboard shortcut to turn the theme on or off.
- Scoped to SAP CPI hosts only. Other sites are never themed.
- No network access, no analytics, and no remote code. Settings are stored locally and sync with your browser profile.

## How it works

The page is themed with a single, efficient CSS filter on the root element:

```
html { filter: invert(100%) hue-rotate(180deg) brightness(B%) contrast(C%) sepia(W%) grayscale(G%) }
```

SAP CPI uses a light interface, so the invert and hue rotate stages turn it dark while keeping hues recognizable. Contrast below 100 lifts the result to a soft charcoal and eases harsh white text. Warmth reduces blue light. Images, logos, and video are inverted a second time so they look natural rather than negative.

Saturation is the setting shown in the interface. The content script converts it to the CSS grayscale value at the single point where the filter is built, because CSS exposes grayscale rather than saturation.

This is a filter based theme. It covers the whole application quickly and consistently, including the integration flow editor. It is not a per control color mapping, so semantic colors are approximated, but the defaults are tuned to keep SAP status colors readable.

## Comfort presets

| Preset  | Brightness | Contrast | Warmth | Best for                        |
| ------- | ---------- | -------- | ------ | ------------------------------- |
| Soft    | 108        | 74       | 12     | tired eyes or dim rooms         |
| Comfort | 105        | 80       | 8      | everyday balanced charcoal      |
| Deep    | 100        | 92       | 5      | bright rooms or higher contrast |

## Install for testing

1. Download and extract the package.
2. Open the extensions page in your browser and enable Developer mode.
3. Choose Load unpacked and select the extracted folder.
4. Open SAP CPI and use the toolbar icon to toggle, pick a preset, or fine tune.

## Keyboard shortcut

The default toggle shortcut is Alt+Shift+D. To set or change it, open the browser shortcuts page:

```
chrome://extensions/shortcuts
```

Find SAP CPI Dark Mode, click the input next to Turn SAP CPI Dark Mode on or off, and press your preferred combination. The popup shows the shortcut that is currently bound.

## Permissions

- storage: remembers your preferences and keeps them in sync with your browser profile.
- tabs: lets the popup confirm that the current tab is a SAP CPI page so it can show accurate status. The extension does not read page content.
- Host access to SAP business technology platform hosts: so the content script can apply the theme on SAP CPI pages only.

The extension requests nothing beyond what it needs to function.

## Privacy

This extension does not collect, transmit, or sell any data. All settings stay in your browser. See PRIVACY.md for the full statement.

## Notes and limitations

- Filter based theming approximates semantic colors rather than mapping each control. The defaults keep SAP status colors readable.
- Native browser tooltips cannot be styled by any extension.
- SF Pro Display is used for the toolbar interface only, with a system fallback on non Apple platforms. No font files are bundled.

## Project structure

```
dark-mode/
  manifest.json
  javascript/
    background.js     service worker for the keyboard command and first run defaults
    content.js        the filter engine and self healing style injection
  popup.html
  style.css           toolbar interface styling, SF Pro Display for the popup only
  popup.js            presets, fine tune, debounced saves, tab detection
  icons/
    icon_16.png
    icon_48.png
    icon_128.png
  README.md
  PRIVACY.md
  STORE_LISTING.md
```
