# Privacy Policy

SAP CPI Dark Mode is designed with privacy as a priority.

## What the extension does

The extension applies a dark theme to SAP Integration Suite and SAP Cloud Integration pages in your browser. It stores your display preferences, such as whether the theme is on and your brightness, contrast, warmth, and saturation settings.

## Data collection

The extension does not collect, transmit, or sell any personal data. It has no analytics, no tracking, and no remote code. It makes no network requests of its own.

## Data storage

Your preferences are stored using the browser storage sync feature. This keeps your settings on your own browser profile and, if you are signed in to your browser, syncs them across your devices through your browser account. The developer has no access to this data.

## Permissions

- storage: used only to save and read your preferences.
- tabs: used only so the popup can confirm that the active tab is a SAP CPI page and show accurate status. The extension does not read page content.
- Host access to SAP business technology platform hosts: used only to apply the theme on SAP CPI pages. The extension does not read page content and does not send any page data anywhere.

## Contact

For questions about this policy, please use the support contact listed on the extension store page.
