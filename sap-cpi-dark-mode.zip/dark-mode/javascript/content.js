/*
 * SAP CPI Dark Mode - content script
 *
 * Applies a comfortable charcoal dark theme to SAP Integration Suite and SAP
 * Cloud Integration using a single, GPU friendly CSS filter on the root
 * element:
 *
 *   html { filter: invert(100%) hue-rotate(180deg)
 *                  brightness(B%) contrast(C%) sepia(W%) grayscale(G%) }
 *
 * Rationale for each stage:
 *   invert + hue-rotate  turns the light SAP interface dark while preserving
 *                        recognizable hues.
 *   contrast below 100   lifts the inverted pure black to a soft charcoal and
 *                        eases harsh inverted white text, which reduces glare.
 *   sepia (warmth)       lowers blue light for comfort during long sessions.
 *                        Kept small so SAP status colors stay recognizable.
 *   grayscale            reduces color intensity. This is derived from the
 *                        canonical saturation setting as grayscale = 100 minus
 *                        saturation. CSS exposes grayscale rather than
 *                        saturation, so this file is the single place where the
 *                        conversion happens.
 *
 * Real media such as images, logos, and video are inverted a second time so
 * they render normally rather than as negatives.
 *
 * The script runs only in the top document of SAP CPI hosts. Running in nested
 * same origin frames would invert their content twice and cancel the effect,
 * so all_frames is disabled in the manifest by design.
 */

(function () {
  "use strict";

  var STYLE_ID = "sap-cpi-dark-mode-style";

  // Canonical settings. saturation is used everywhere in storage and UI; it is
  // converted to a CSS grayscale value only when the filter string is built.
  var DEFAULTS = {
    enabled: true,
    brightness: 105,
    contrast: 80,
    warmth: 8,
    saturation: 100
  };

  var LIMITS = {
    brightness: [50, 150],
    contrast: [50, 150],
    warmth: [0, 60],
    saturation: [0, 100]
  };

  var state = null;
  var observer = null;
  var injecting = false;

  function clamp(value, key) {
    var range = LIMITS[key];
    var n = Number(value);
    if (isNaN(n)) {
      return DEFAULTS[key];
    }
    if (n < range[0]) {
      return range[0];
    }
    if (n > range[1]) {
      return range[1];
    }
    return n;
  }

  function buildFilter(cfg) {
    var b = clamp(cfg.brightness, "brightness");
    var c = clamp(cfg.contrast, "contrast");
    var w = clamp(cfg.warmth, "warmth");
    var s = clamp(cfg.saturation, "saturation");
    var grayscale = 100 - s;

    var parts = ["invert(100%)", "hue-rotate(180deg)"];
    if (b !== 100) {
      parts.push("brightness(" + b + "%)");
    }
    if (c !== 100) {
      parts.push("contrast(" + c + "%)");
    }
    if (w !== 0) {
      parts.push("sepia(" + w + "%)");
    }
    if (grayscale !== 0) {
      parts.push("grayscale(" + grayscale + "%)");
    }
    return parts.join(" ");
  }

  function buildCss(cfg) {
    var filter = buildFilter(cfg);
    var mediaFilter = "invert(100%) hue-rotate(180deg)";

    return [
      "@media screen {",
      "  html {",
      "    -webkit-filter: " + filter + " !important;",
      "    filter: " + filter + " !important;",
      "  }",
      "  html {",
      "    text-shadow: 0 0 0 !important;",
      "  }",
      "  img, picture, video, canvas, iframe, embed, object,",
      "  [style*=\"background-image:url\"], [style*=\"background-image: url\"],",
      "  [class*=\"logo\"] img, .sapMImg, image {",
      "    -webkit-filter: " + mediaFilter + " !important;",
      "    filter: " + mediaFilter + " !important;",
      "  }",
      "  *:-webkit-full-screen, *:-webkit-full-screen * {",
      "    -webkit-filter: none !important;",
      "    filter: none !important;",
      "  }",
      "}"
    ].join("\n");
  }

  function removeStyle() {
    var node = document.getElementById(STYLE_ID);
    if (node && node.parentNode) {
      node.parentNode.removeChild(node);
    }
  }

  function injectStyle(css) {
    var root = document.documentElement;
    if (!root) {
      return;
    }
    var existing = document.getElementById(STYLE_ID);
    if (existing) {
      if (existing.textContent !== css) {
        existing.textContent = css;
      }
      return;
    }
    injecting = true;
    var style = document.createElement("style");
    style.id = STYLE_ID;
    style.type = "text/css";
    style.textContent = css;
    root.appendChild(style);
    injecting = false;
  }

  function render() {
    if (!state) {
      return;
    }
    if (state.enabled) {
      injectStyle(buildCss(state));
    } else {
      removeStyle();
    }
  }

  function normalize(cfg) {
    return {
      enabled: cfg.enabled !== false,
      brightness: clamp(cfg.brightness, "brightness"),
      contrast: clamp(cfg.contrast, "contrast"),
      warmth: clamp(cfg.warmth, "warmth"),
      saturation: clamp(cfg.saturation, "saturation")
    };
  }

  function loadAndRender() {
    try {
      chrome.storage.sync.get(DEFAULTS, function (cfg) {
        state = normalize(cfg);
        render();
      });
    } catch (e) {
      state = normalize(DEFAULTS);
      render();
    }
  }

  // Self healing. If a very aggressive page ever removes our style node while
  // the theme is enabled, put it back. The observer watches only the direct
  // children of the root element, which is inexpensive, and it ignores changes
  // that we cause ourselves.
  function startObserver() {
    if (observer || typeof MutationObserver === "undefined") {
      return;
    }
    observer = new MutationObserver(function () {
      if (injecting) {
        return;
      }
      if (state && state.enabled && !document.getElementById(STYLE_ID)) {
        render();
      }
    });
    try {
      observer.observe(document.documentElement, { childList: true });
    } catch (e) {
      observer = null;
    }
  }

  // Apply as early as possible to avoid a flash of the light interface.
  loadAndRender();
  startObserver();

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () {
      render();
    }, { once: true });
  }

  // Live updates from the popup or the keyboard command.
  try {
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== "sync") {
        return;
      }
      if (changes.enabled || changes.brightness || changes.contrast ||
          changes.warmth || changes.saturation) {
        loadAndRender();
      }
    });
  } catch (e) {}

  // Lets the popup confirm that this tab is a SAP CPI page.
  try {
    chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
      if (message && message.type === "cpiDark:ping") {
        sendResponse({
          cpi: true,
          enabled: state ? state.enabled : true
        });
      }
      return false;
    });
  } catch (e) {}
})();
