/*
 * SAP CPI Dark Mode - background service worker
 *
 * Responsibilities:
 *   1. Seed sensible defaults on first install without overwriting a returning
 *      user's saved preferences.
 *   2. Handle the keyboard command to turn the theme on or off. The content
 *      script listens for storage changes, so the page updates live with no
 *      reload and with the popup closed.
 *
 * Settings schema (shared across background, content, and popup):
 *   schemaVersion  number   storage schema version, owned and written here
 *   enabled        boolean  whether the theme is applied
 *   brightness     number   percent, engine range 50 to 150
 *   contrast       number   percent, engine range 50 to 150
 *   warmth         number   percent of sepia, engine range 0 to 60
 *   saturation     number   percent of color intensity, engine range 0 to 100
 *
 * saturation is the canonical color setting everywhere. The content script is
 * the only place that converts it to the CSS grayscale value, because CSS
 * exposes grayscale rather than saturation.
 *
 * The worker keeps no long lived state. It reads storage, changes a value, and
 * writes it back, so it stays small and reliable.
 */

"use strict";

var SCHEMA_VERSION = 1;

var DEFAULTS = {
  schemaVersion: SCHEMA_VERSION,
  enabled: true,
  brightness: 105,
  contrast: 80,
  warmth: 8,
  saturation: 100
};

function seedDefaults() {
  chrome.storage.sync.get(null, function (stored) {
    var toWrite = {};
    Object.keys(DEFAULTS).forEach(function (key) {
      if (typeof stored[key] === "undefined") {
        toWrite[key] = DEFAULTS[key];
      }
    });
    // Keep the stored schema version current. Partial writes elsewhere never
    // touch this key, so it is safe to own it here.
    if (stored.schemaVersion !== SCHEMA_VERSION) {
      toWrite.schemaVersion = SCHEMA_VERSION;
    }
    if (Object.keys(toWrite).length > 0) {
      chrome.storage.sync.set(toWrite);
    }
  });
}

chrome.runtime.onInstalled.addListener(function () {
  seedDefaults();
});

chrome.runtime.onStartup.addListener(function () {
  seedDefaults();
});

chrome.commands.onCommand.addListener(function (command) {
  if (command !== "toggleDarkMode") {
    return;
  }
  chrome.storage.sync.get({ enabled: true }, function (cfg) {
    chrome.storage.sync.set({ enabled: !cfg.enabled });
  });
});
