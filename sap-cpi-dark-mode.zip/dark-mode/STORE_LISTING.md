# Chrome Web Store Listing Kit

Copy and paste the fields below into the developer dashboard. Nothing here needs editing to pass review, but you may adjust wording to match your voice.

## Name
SAP CPI Dark Mode

## Summary (up to 132 characters)
A comfortable charcoal dark theme for SAP Integration Suite and Cloud Integration, with warmth control to reduce eye strain.

## Category
Developer Tools

## Detailed description

SAP CPI Dark Mode gives SAP Integration Suite and SAP Cloud Integration a comfortable charcoal dark theme that is easy on the eyes during long working sessions.

Key features:

- Comfortable charcoal appearance that avoids a harsh pure black.
- One click comfort presets: Soft, Comfort, and Deep.
- Fine tune controls for Brightness, Contrast, Warmth, and Saturation.
- Warmth control lowers blue light for easier reading late in the day.
- Keyboard shortcut to turn the theme on or off.
- Applies only to SAP CPI pages. Other websites are never themed.
- No network access, no analytics, and no remote code. Your settings stay in your browser.

The theme covers the whole application quickly and consistently, including the integration flow editor. Images and logos are handled so they continue to look natural.

Note: this is a filter based theme. It approximates colors across the interface rather than mapping each control individually. The defaults are tuned so SAP status colors stay readable.

## Permission justifications

- storage: saves your display preferences and syncs them with your browser profile.
- tabs: lets the popup confirm that the active tab is a SAP CPI page so it can show accurate status. The extension does not read page content.
- Host access to SAP business technology platform hosts: required so the content script can apply the theme on SAP CPI pages only.

## Single purpose statement
The single purpose of this extension is to apply an optional dark theme to SAP Integration Suite and SAP Cloud Integration pages.

## Data usage disclosures
- Does the item collect user data: No.
- Sold to third parties: No.
- Used or transferred for purposes unrelated to the item core functionality: No.
- Used or transferred to determine creditworthiness or for lending: No.

## Assets checklist
- Store icon: 128 by 128 PNG. Use icons/icon_128.png as a base or a higher resolution export.
- At least one screenshot at 1280 by 800 or 640 by 400. Capture the Home, Monitor, and integration flow editor with the theme on.
- Optional small promo tile: 440 by 280.

## Privacy policy
Host the contents of PRIVACY.md at a public URL and paste that URL into the Privacy practices tab.
