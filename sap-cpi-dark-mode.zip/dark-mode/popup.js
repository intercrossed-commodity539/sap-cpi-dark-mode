/*
 * SAP CPI Dark Mode - popup controller.
 *
 * Reads and writes preferences, drives the comfort presets and fine tune
 * sliders, detects whether the active tab is a SAP CPI page, and keeps the
 * popup in sync if the state changes elsewhere. Writes to storage are debounced
 * so dragging a slider stays well within the sync write limits.
 *
 * saturation is the canonical color setting and is stored directly. The content
 * script is the only place that converts it to a CSS grayscale value.
 */

(function () {
  "use strict";

  var DEFAULTS = {
    enabled: true,
    brightness: 105,
    contrast: 80,
    warmth: 8,
    saturation: 100
  };

  // Presets keep colors at full saturation by default so SAP status colors
  // remain clear.
  var PRESETS = {
    soft: {
      brightness: 108, contrast: 74, warmth: 12, saturation: 100,
      hint: "Lighter charcoal with a little more warmth for tired eyes."
    },
    comfort: {
      brightness: 105, contrast: 80, warmth: 8, saturation: 100,
      hint: "Balanced charcoal with gentle warmth."
    },
    deep: {
      brightness: 100, contrast: 92, warmth: 5, saturation: 100,
      hint: "Darker with higher contrast for bright rooms."
    }
  };

  var el = {
    enabled: document.getElementById("enabled"),
    status: document.getElementById("status"),
    presetHint: document.getElementById("presetHint"),
    advToggle: document.getElementById("advToggle"),
    adv: document.getElementById("adv"),
    reset: document.getElementById("reset"),
    shortcut: document.getElementById("shortcut"),
    brightness: document.getElementById("brightness"),
    brightnessVal: document.getElementById("brightnessVal"),
    contrast: document.getElementById("contrast"),
    contrastVal: document.getElementById("contrastVal"),
    warmth: document.getElementById("warmth"),
    warmthVal: document.getElementById("warmthVal"),
    saturation: document.getElementById("saturation"),
    saturationVal: document.getElementById("saturationVal")
  };

  var segButtons = Array.prototype.slice.call(document.querySelectorAll(".seg"));
  var cards = Array.prototype.slice.call(document.querySelectorAll(".card"));

  var saveTimer = null;
  var suppressChangeListener = false;

  function setStatus(text, kind) {
    el.status.textContent = text;
    el.status.className = "status status-" + (kind || "muted");
  }

  function reflectControls(cfg) {
    el.brightness.value = cfg.brightness;
    el.brightnessVal.textContent = cfg.brightness;

    el.contrast.value = cfg.contrast;
    el.contrastVal.textContent = cfg.contrast;

    el.warmth.value = cfg.warmth;
    el.warmthVal.textContent = cfg.warmth;

    el.saturation.value = cfg.saturation;
    el.saturationVal.textContent = cfg.saturation;
  }

  function matchPreset(cfg) {
    var names = Object.keys(PRESETS);
    for (var i = 0; i < names.length; i++) {
      var p = PRESETS[names[i]];
      if (Number(cfg.brightness) === p.brightness &&
          Number(cfg.contrast) === p.contrast &&
          Number(cfg.warmth) === p.warmth &&
          Number(cfg.saturation) === p.saturation) {
        return names[i];
      }
    }
    return null;
  }

  function highlightPreset(name) {
    segButtons.forEach(function (btn) {
      var on = btn.getAttribute("data-preset") === name;
      btn.setAttribute("aria-pressed", on ? "true" : "false");
    });
    if (name && PRESETS[name]) {
      el.presetHint.textContent = PRESETS[name].hint;
    } else {
      el.presetHint.textContent = "Custom settings.";
    }
  }

  function applyEnabledUiState() {
    var on = el.enabled.checked;
    [el.brightness, el.contrast, el.warmth, el.saturation].forEach(function (input) {
      input.disabled = !on;
    });
    segButtons.forEach(function (btn) { btn.disabled = !on; });
    el.advToggle.disabled = !on;
    cards.forEach(function (card) { card.classList.toggle("is-disabled", !on); });
    el.reset.classList.toggle("is-disabled", !on);
  }

  function saveNow(part) {
    try {
      suppressChangeListener = true;
      chrome.storage.sync.set(part, function () {
        suppressChangeListener = false;
      });
    } catch (e) {
      suppressChangeListener = false;
    }
  }

  function saveDebounced(part) {
    if (saveTimer) {
      clearTimeout(saveTimer);
    }
    saveTimer = setTimeout(function () {
      saveTimer = null;
      saveNow(part);
    }, 120);
  }

  function currentConfigFromControls() {
    return {
      brightness: Number(el.brightness.value),
      contrast: Number(el.contrast.value),
      warmth: Number(el.warmth.value),
      saturation: Number(el.saturation.value)
    };
  }

  function load() {
    chrome.storage.sync.get(DEFAULTS, function (cfg) {
      el.enabled.checked = cfg.enabled !== false;
      reflectControls(cfg);
      highlightPreset(matchPreset(cfg));
      applyEnabledUiState();
    });
  }

  // Toggle
  el.enabled.addEventListener("change", function () {
    saveNow({ enabled: el.enabled.checked });
    applyEnabledUiState();
  });

  // Presets
  segButtons.forEach(function (btn) {
    btn.addEventListener("click", function () {
      var preset = PRESETS[btn.getAttribute("data-preset")];
      if (!preset) {
        return;
      }
      reflectControls(preset);
      highlightPreset(btn.getAttribute("data-preset"));
      saveNow({
        brightness: preset.brightness,
        contrast: preset.contrast,
        warmth: preset.warmth,
        saturation: preset.saturation
      });
    });
  });

  // Fine tune disclosure
  el.advToggle.addEventListener("click", function () {
    var isHidden = el.adv.hasAttribute("hidden");
    if (isHidden) {
      el.adv.removeAttribute("hidden");
      el.advToggle.setAttribute("aria-expanded", "true");
    } else {
      el.adv.setAttribute("hidden", "");
      el.advToggle.setAttribute("aria-expanded", "false");
    }
  });

  // Sliders
  function bindRange(input, valueEl) {
    input.addEventListener("input", function () {
      valueEl.textContent = input.value;
      var cfg = currentConfigFromControls();
      highlightPreset(matchPreset(cfg));
      saveDebounced(cfg);
    });
    input.addEventListener("change", function () {
      // Final commit, in case the debounce was still pending.
      saveNow(currentConfigFromControls());
    });
  }

  bindRange(el.brightness, el.brightnessVal);
  bindRange(el.contrast, el.contrastVal);
  bindRange(el.warmth, el.warmthVal);
  bindRange(el.saturation, el.saturationVal);

  // Reset to Comfort
  el.reset.addEventListener("click", function () {
    var preset = PRESETS.comfort;
    el.enabled.checked = true;
    reflectControls(preset);
    highlightPreset("comfort");
    applyEnabledUiState();
    saveNow({
      enabled: true,
      brightness: preset.brightness,
      contrast: preset.contrast,
      warmth: preset.warmth,
      saturation: preset.saturation
    });
  });

  // Keep the popup in sync if the keyboard command or another window changes state.
  chrome.storage.onChanged.addListener(function (changes, area) {
    if (area !== "sync" || suppressChangeListener) {
      return;
    }
    chrome.storage.sync.get(DEFAULTS, function (cfg) {
      el.enabled.checked = cfg.enabled !== false;
      reflectControls(cfg);
      highlightPreset(matchPreset(cfg));
      applyEnabledUiState();
    });
  });

  // Detect whether the active tab is a SAP CPI page by pinging the content
  // script. The tabs permission is declared in the manifest.
  function detectTab() {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      var tab = tabs && tabs[0];
      if (!tab || typeof tab.id !== "number") {
        setStatus("No active tab.", "muted");
        return;
      }
      try {
        chrome.tabs.sendMessage(tab.id, { type: "cpiDark:ping" }, function (response) {
          if (chrome.runtime.lastError || !response) {
            setStatus("This tab is not a SAP CPI page. The theme stays off here.", "warn");
            return;
          }
          setStatus("SAP CPI page detected.", "ok");
        });
      } catch (e) {
        setStatus("This tab is not a SAP CPI page. The theme stays off here.", "warn");
      }
    });
  }

  // Show the real toggle shortcut if the browser reports one.
  function showShortcut() {
    if (!chrome.commands || !chrome.commands.getAll) {
      return;
    }
    chrome.commands.getAll(function (commands) {
      var found = null;
      (commands || []).forEach(function (c) {
        if (c.name === "toggleDarkMode" && c.shortcut) {
          found = c.shortcut;
        }
      });
      el.shortcut.textContent = found ? found : "Not set";
    });
  }

  load();
  detectTab();
  showShortcut();
})();
